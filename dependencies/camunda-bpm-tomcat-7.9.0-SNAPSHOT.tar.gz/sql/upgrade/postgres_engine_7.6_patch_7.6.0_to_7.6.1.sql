alter table ACT_RU_EVENT_SUBSCR
  alter column ACTIVITY_ID_ type varchar(255);