alter table ACT_HI_JOB_LOG
  alter column ACT_ID_ type varchar(255);
